cara pemakaian 

1. pkg install python2
2. pkg install curl
3. pkg install termux-api
4. pip2 install colorama
5. pip2 install requests
6. pip2 install bs4
7. pkg update
8. pkg upgrade
9. run ( python2 999dice.py )
10. untuk Stop Bot ( ctrl + 4 )