# 999dice_bot
It's initial version of 999dice.com Python2 library!

## Downloads
You can grab this file to your media with git
On Termux 
```
- pkg install git
- git clone https://github.com/proj-dice/999dice_bot.git

```

## Install

You can install package using install.sh:

```bash
# Install package

sh install.sh

```

## Run On Termux Or Linux

```bash
python2 doge.py
```

